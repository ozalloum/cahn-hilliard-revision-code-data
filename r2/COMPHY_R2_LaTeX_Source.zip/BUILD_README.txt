Manuscript document build

This folder contains the complete clean and marked manuscript sources,
the CAS template files and the original standalone figure files.
The numerical code/data release is linked in Supplementary Material S1.

With a standard TeX Live or MiKTeX installation including Latin Modern,
PGF/TikZ, pgfplots, natbib and the template's dependencies, run:

  latexmk -pdf -interaction=nonstopmode COMPHY_R2_clean.tex
  latexmk -pdf -interaction=nonstopmode COMPHY_R2_marked.tex

Both manuscripts contain the same text. The marked version colors the
current language/readability and disclosure edits blue.

The figures are embedded in the manuscript source. The figures folder
also preserves the original standalone exports and export script.
No research computations are needed to build the manuscript PDFs.
