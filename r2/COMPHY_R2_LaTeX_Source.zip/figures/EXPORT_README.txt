FIGURE EXPORTS

Figure_1.tex through Figure_8.tex contain the exact audited manuscript figure
blocks, including embedded data/field rectangles and captions. They require
pdfLaTeX with amsmath, amssymb, bm, booktabs, array, xcolor, graphicx, tikz,
pgfplots and url. No external data file is needed for these exact-source plots.

Example from this folder:
  pdflatex -interaction=nonstopmode -halt-on-error Figure_5.tex
  pdflatex -interaction=nonstopmode -halt-on-error Figure_5.tex

Compile into a separate directory to preserve the delivered cropped PDF.
The standalone figure sources retain the article layout used for their exports;
the full manuscript uses the supplied cas-sc journal template.
The delivered PDFs were cropped around figure/caption content without
rasterizing the vector paths. PNGs are 700 dpi renders of those PDFs.
TIFF_700dpi/Figure_1.tiff through Figure_8.tiff contain artwork only, rendered
directly from the vector drawing sources at 700 x 700 dpi with lossless LZW
compression and RGB colour. Upload these as the separate figure files; the
editable captions remain in the manuscript. Figure numbering matches the text.
The companion data and numerics/validation/figures.py can regenerate the
five later figure blocks from their numerical records. figure_captions.json
must remain beside figures.py. The full manuscript source is authoritative
for figure placement and numbering. Final captions refer to manuscript table
and equation numbers embedded in the standalone sources.
