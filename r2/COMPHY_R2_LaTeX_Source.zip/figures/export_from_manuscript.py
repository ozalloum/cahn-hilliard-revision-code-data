from pathlib import Path
import re,argparse
p=argparse.ArgumentParser();p.add_argument('manuscript',type=Path);p.add_argument('--output',type=Path,default=Path('figures_exported'));a=p.parse_args()
s=a.manuscript.read_text(encoding='utf-8');a.output.mkdir(parents=True,exist_ok=True)
preamble=s.split(r'\begin{document}',1)[0].replace(r'\markedtrue',r'\markedfalse')
aux=a.manuscript.with_suffix('.aux')
labels=''
if aux.exists():labels='\n'.join(x for x in aux.read_text().splitlines() if x.startswith(r'\newlabel') and not x.startswith(r'\newlabel{fig:'))
else: print('Compile the manuscript first and keep its .aux file to resolve cross-references in standalone captions.')
for i,b in enumerate(re.findall(r'\\begin\{figure\}.*?\\end\{figure\}',s,re.S),1):
    doc=preamble+'\n'+r'\makeatletter'+'\n'+labels+'\n'+r'\makeatother\pagestyle{empty}\begin{document}\setcounter{figure}{'+str(i-1)+'}\n'+b+'\n'+r'\clearpage\end{document}'
    (a.output/f'Figure_{i}.tex').write_text(doc,encoding='utf-8')
print('Wrote exact-source figure documents to',a.output)
