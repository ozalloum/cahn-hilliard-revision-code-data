FIGURE SOURCES AND EXPORTS

Figure_1.tex through Figure_8.tex are standalone figure sources with
embedded data and captions. They require pdfLaTeX with amsmath, amssymb,
bm, booktabs, array, xcolor, graphicx, tikz, pgfplots and url.

Example from this folder:
  pdflatex -interaction=nonstopmode -halt-on-error Figure_5.tex
  pdflatex -interaction=nonstopmode -halt-on-error Figure_5.tex

Compile into a separate output directory to preserve the supplied PDFs.
The PDFs contain vector graphics and captions. The PNGs are 700 dpi renders
of the PDFs. TIFF_700dpi contains artwork-only exports at 700 x 700 dpi,
with lossless LZW compression and RGB colour.

The numerical release includes the data and numerics/validation/figures.py
needed to regenerate the five later figure blocks. Keep figure_captions.json
beside figures.py. Table and equation numbers in the standalone captions
refer to the article.

export_from_manuscript.py can extract figure blocks from a separately
supplied manuscript source and its compiled .aux file.
